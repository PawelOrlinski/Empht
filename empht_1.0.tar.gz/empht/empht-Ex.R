pkgname <- "empht"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('empht')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("empht")
### * empht

flush(stderr()); flush(stdout())

### Name: empht
### Title: Aproksymacja rozkładami fazowymi przy użyciu algorytmu EM.
### Aliases: empht
### Keywords: ~kwd1 ~kwd2

### ** Examples


##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--	or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (input, densityChoice, truncpoint, maxprob, maxdeltat, 
    parameter, p, structure, random_init, NoOfEMsteps, stepchoice, 
    RKstep) 
{
    result = .C("empht", input = 2, densityChoice = as.integer(c(densityChoice)), 
        truncpoint = as.double(c(truncpoint)), maxprob = as.double(c(maxprob)), 
        maxdeltat = as.double(c(maxdeltat)), parameter = as.double(parameter), 
        p = as.integer(c(p)), structure = as.integer(c(structure)), 
        random_init = as.integer(c(random_init)), NoOfEMsteps = as.integer(c(NoOfEMsteps)), 
        stepchoice = as.integer(c(stepchoice)), RKstep = as.double(c(RKstep)), 
        pi = as.double(rep(0, p)), T = as.double(rep(0, p * p)), 
        t = as.double(rep(0, p)), loglikelihood = as.double(c(0)))
    list(pi = result$pi, T = matrix(result$T, nrow = p, byrow = TRUE), 
        t = result$t, loglikelihood = result$loglikelihood)
  }



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
